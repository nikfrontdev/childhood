<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе
 * установки. Необязательно использовать веб-интерфейс, можно
 * скопировать файл в "wp-config.php" и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки MySQL
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'childhood' );

/** Имя пользователя MySQL */
define( 'DB_USER', 'Child_admin' );

/** Пароль к базе данных MySQL */
define( 'DB_PASSWORD', 'nikita' );

/** Имя сервера MySQL */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'ps7@h%5^*`E@MdPR} t]|oqf.gWSr)3Dc6%;S*6=P>e@SvG{Uj7HkIZ0/lloA:Lw' );
define( 'SECURE_AUTH_KEY',  '[?Y7Ne.W{P%yzz}GH_s38}8<!2+Zpr]_W/xj@ORx6UD)^]d@JcjW`/!ykfdt3+HC' );
define( 'LOGGED_IN_KEY',    'YA^oM5/sAEhyZ0:3>bNwd*BXaM)]3^&ZaktVr_$<}KkD=)eDT5eZ-sB|:/^L-b>N' );
define( 'NONCE_KEY',        'oN!@*l2jpwRIPv.(STE5}Aq~h(!R:Cg|?hO$AuGfSHPS1pZ-bn0GCEL^f#]3`Q7U' );
define( 'AUTH_SALT',        'bldv!XTY%.GdtDfK)g^2kt6cLfd*Tr~,5!MsbAR`]it!,B/U,sE8EXVsaDstzZ`8' );
define( 'SECURE_AUTH_SALT', 'iiOvFtF5 wJKsjZt{mg>}W_30gf!<kv6p6yr]|8?S#__W9kOZD`bI-WF$F&6l0j,' );
define( 'LOGGED_IN_SALT',   'Dl*~lY@Q@/HlWp,cCRtX|G|A?OzQjiZi<?Fqf V[$1~OPNqXgeHY%zGl0+>Kwejg' );
define( 'NONCE_SALT',       '(:/<f4_tZnn_~sFze_<nJu@3/vL2Nc`M4V{3UM31&ZNjjAcNbeud@)&)Wdvq@5vf' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в Кодексе.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once( ABSPATH . 'wp-settings.php' );
